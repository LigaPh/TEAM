<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Responsive sidebar template with sliding effect and dropdown menu based on bootstrap 3">
    <title>Team Statistics</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/jquery.mCustomScrollbar.min.css" />
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/css/custom-themes.css">
    <link rel="shortcut icon" type="image/png" href="assets/img/liga.png" />
</head>

<body>
    <div class="page-wrapper chiller-theme toggled">
        <nav id="sidebar" class="sidebar-wrapper">
            <div class="sidebar-content">
                <div id="sidebar-fixed">
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
                <div class="sidebar-brand">
                    <a href="LigaPH/players.php">
                        <img src="assets/img/icon.png" width="10%" height="10%" />LigaPH
                    </a>
                </div>
                <div class="sidebar-header">
                    <div class="user-pic">
                        <a href="index.php"><img class="img-responsive img-rounded" src="assets/img/user.jpg" alt="User picture">
                        </a>
                    </div>
                    <div class="user-info">
                        <span class="user-name">Phoenix
                            <strong>Team</strong>
                        </span>
                        <span class="user-role">Team Name</span>
                        <span class="user-status">
                            <i class="fa fa-circle"></i>
                            <span>Online</span>
                        </span>
                    </div>
                </div>

                <div class="sidebar-menu">
                    <ul>
                        <li class="header-menu">
                            <span></span>
                        </li>
                        <li class="">
                            <a href="teamsprof.php">
                                <i class="fa fa-dashboard"></i>
                                <span>Home</span>
                            </a>
                        </li>
                        <li class="sidebar-dropdown">
                            <a href="#">
                                <i class="fa fa-dashboard"></i>
                                <span>Tournaments</span>
                                <span class="label label-danger">New</span>
                            </a>
                            <div class="sidebar-submenu">
                                <ul>
                                    <li class="sidebar-dropdown">
                                        <a href="bbview.php">Basketball
                                        </a>
                                    </li>
                                    <li>
                                        <a href="vbview.php">Volleyball</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="sidebar-dropdown">
                            <a href="#">
                                <i class="fa fa-shopping-cart"></i>
                                <span>Schedules & Scores</span>
                                <span class="badge">3</span>
                            </a>
                            <div class="sidebar-submenu">
                                <ul>
                                    <li>
                                        <a href="tournasched.php">Schedules
                                            <span class="badge">2</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="teamscore.php">Scores</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="sidebar-dropdown">
                            <a href="#">
                                <i class="fa fa-diamond"></i>
                                <span>Statistics</span>
                            </a>
                            <div class="sidebar-submenu">
                                <ul>
                                    <li class="sidebar-dropdown">
                                        <a href="teamstat.php">Teams Statistic</a>
                                    </li>
                                    <li>
                                        <a href="playerstat.php">Player Statistic</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="sidebar-dropdown">
                            <a href="#">
                                <i class="fa fa-bar-chart-o"></i>
                                <span>Game Recap</span>
                            </a>
                            <div class="sidebar-submenu">
                                <ul>
                                    <li class="sidebar-dropdown">
                                        <a href="#">Game Videos</a>
                                        <ul>
                                            <li>
                                                <a href="#">Basketball</a>
                                            <li>
                                                <a href="#">Volleyball</a>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
                <!-- sidebar-menu  -->
            </div>
            <!-- sidebar-content  -->
            <div class="sidebar-footer">
                <a href="#">
                    <i class="fa fa-bell"></i>
                    <span class="label label-warning notification">3</span>
                </a>
                <a href="#">
                    <i class="fa fa-envelope"></i>
                    <span class="label label-success notification">7</span>
                </a>
                <a href="#">
                    <i class="fa fa-gear"></i>
                    <span class="badge-sonar"></span>
                </a>
                <a href="index.php">
                    <i class="fa fa-power-off"></i>
                </a>
            </div>
        </nav>
        <!-- sidebar-wrapper  -->
        <main class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div style="padding-top: 20px;"></div>
                        <center><h2><b>BASKETBALL</b></h2></center>
                            <div class="col-md-3 col-sm-5 pull-left">     
                                <div class="input-group">
                                    <div class="input-group-btn search-panel">
                                        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                            <span id="search_concept">Basketball</span><span class="caret"></span>
                                        </button>
                                        <ul class="dropdown-menu" role="menu">
                                            <li><a href="#">Basketball</a></li>
                                            <li><a href="#">Volleyball</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>    
                    <!-- search -->
                    <div class="col-md-3 col-sm-5 pull-right">     
                        <div class="input-group">
                            <input type="hidden" name="search_param" value="all" id="search_param">         
                            <input type="text" class="form-control" name="x" placeholder="Search">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="button"><span class="glyphicon glyphicon-search"></span></button>
                            </span>
                        </div>
                    </div>
                    <div style="padding-top: 50px;"></div>
                            <table class="table table-condensed" align="center">
                                <thead>
                                    <tr style="background-color: black; color: white;">
                                        <th>Team Name</th>
                                        <th>Coach</th>
                                        <th>Wins</th>
                                        <th>Loss</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Ginebra</td>
                                        <td>Alesna</td>
                                        <td>5</td>
                                        <td>0</td>                                    
                                    </tr>
                                    <tr>
                                        <td>San Miguel</td>
                                        <td>Lastimoso</td>
                                        <td>4</td>
                                        <td>1</td>           
                                    </tr>
                                    <tr>
                                        <td>Lebron</td>
                                        <td>Chiu</td>
                                        <td>2</td>
                                        <td>3</td>  
                                    </tr> 
                                </tbody>
                            </table>
                        </div>
                </div>
            </div>
        </main>
        <!-- page-content" -->
    </div>
    <!-- page-wrapper -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="assets/js//jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="assets/js/custom.js"></script>
</body>

</html>