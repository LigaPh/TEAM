<!-- <html>
<head>
    <title></title>
</head>
<body>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/angularjs/1.3.9/angular.min.js"></script>
    <script type="text/javascript">
        var app = angular.module('MyApp', [])
        app.controller('MyController', function ($scope) {
            //This will hide the DIV by default.
            $scope.IsHidden = true;
            $scope.ShowHide = function () {
                //If DIV is hidden it will be visible and vice versa.
                $scope.IsHidden = $scope.IsHidden ? false : true;
            }
        });
    </script>
    <div ng-app="MyApp" ng-controller="MyController">
        <input type="button" value="Show Hide DIV" ng-click="ShowHide()" />
        <br />
        <br />
        <div ng-hide = "IsHidden">My DIV</div>
    </div>
</body>
</html> -->

<!DOCTYPE html>
<html>
<head>
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
   <script>
   
   $(document).ready(function() {
     $("#show_hide").click(function () {
     $("#toggle_tst").toggle()
  });
  });
   </script>
<style>
#toggle_tst{
    width:250px;
    height:250px;
    border: solid 1px green;
    background:#fff;
    margin:20px;
}
</style>
</head>

<body>
<button id="show_hide">Show/Hide div</button> 
   <div id="toggle_tst">
     The div element with some text. <br /><br /> Click Show/hide button to check toggle method!
   </div>

</body>
</html>

