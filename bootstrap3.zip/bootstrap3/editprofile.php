<?php
    include 'nav.php';
?>
<body>
<div class="page-wrapper chiller-theme toggled">
    <nav id="sidebar" class="sidebar-wrapper">
      <div class="sidebar-content">
        <div id="sidebar-fixed">
        <div></div>
        <div></div>
        <div></div>
      </div>
      <div class="sidebar-brand">
        <a href="LigaPH/players.php">
          <img src="assets/img/icon.png" width="10%" height="10%" />LigaPH
        </a>
      </div>
      <div class="sidebar-header">
        <div class="row">
          <div class="col-sm-10"><h1 style="color: white;">User name</h1></div>
          	<div class="col-sm-2"><a href="/users" class="pull-right"><img title="profile image" class="img-circle img-responsive" src="http://www.gravatar.com/avatar/28fd20ccec6865e2d5f0e1f4446eb7bf?s=100"></a></div>
            </div>
            <div class="text-center">
              <img src="http://ssl.gstatic.com/accounts/ui/avatar_2x.png" class="avatar img-circle img-thumbnail" alt="avatar">
                <h6>Upload a different photo...</h6>
                <input type="file" class="text-center center-block file-upload">
            </div>
          </div>
          <div class="sidebar-menu">
          </div>
                <!-- sidebar-menu  -->
          </div>
         <!-- sidebar-content  -->
          <div class="sidebar-footer">
            <a href="#">
              <i class="fa fa-bell"></i>
                <span class="label label-warning notification">3</span>
            </a>
            <a href="#">
              <i class="fa fa-envelope"></i> 
                <span class="label label-success notification">7</span>
            </a>
            <a href="account.php">
              <i class="fa fa-gear"></i>
                <span class="badge-sonar"></span>
            </a>
            <a href="index.php">
              <i class="fa fa-power-off"></i>
            </a>
          </div>
        </div>
    </nav>
</div>
        <!-- sidebar-wrapper  -->
        <!-- page-content" -->  
        <!-- <div class="container bootstrap snippet">
            <div class="row">
                <div class="col-sm-9">
                    <div style="padding-top:100px;"></div>
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#home">Home</a></li>
                            <li><a data-toggle="tab" href="#messages">Menu 1</a></li>
                            <li><a data-toggle="tab" href="#settings">Menu 2</a></li>
                        </ul>              
                        <div class="tab-content">
                            <div class="tab-pane active" id="home">
                                <hr>
                                <form class="form" action="##" method="post" id="registrationForm">
                                    <div class="form-group">              
                                      <div class="col-xs-6">
                                        <label for="last_name"><h4>Team Name</h4></label>
                                          <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Team Name" title="enter your last name if any.">
                                          <label for="first_name"><h4>Team Username</h4></label>
                                          <input type="text" class="form-control" name="first_name" id="first_name" placeholder="Team Username" title="enter your first name if any.">
                                          <label for="last_name"><h4>Leader</h4></label>
                                          <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Leader" title="enter your last name if any.">
                                          <label for="last_name"><h4>Coach</h4></label>
                                          <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Team Name" title="enter your last name if any.">
                                          <label for="password"><h4>Password</h4></label>
                                          <input type="password" class="form-control" name="password" id="password" placeholder="password" title="enter your password.">
                                          <label for="password2"><h4>Confirm Password</h4></label>
                                          <input type="password" class="form-control" name="password2" id="password2" placeholder="Confirm Password" title="enter your password2.">
                                          <div class="form-group row">
                                            <label for="select">Display Name public as</label> 
                                              <div class="col-xs-12">
                                                <div class="form-control">
                                                  <select id="select" name="select" class="custom-select">
                                                    <option value="admin">Player</option>
                                                    <option value="admin">Organizer</option>
                                                  </select>
                                                </div>
                                              </div>
                                              <div class="col-xs-12">
                                                <label for="publicinfo" class="col-4 col-form-label">Public Info</label> 
                                                <div>
                                                  <textarea id="publicinfo" name="publicinfo" cols="40" rows="4" class="form-control"></textarea>
                                                </div>
                                            </div>    
                                          </div>
                                      </div>
                                      <div class="form-group">
                                        <div class="col-xs-6">
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        <div class="col-xs-12"><br>
                                            <button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                                           	<button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>
                                          </div>
                                      </div>
              	                    </div>
                                </form>          
            </div>
        </div>  -->
<script type="text/javascript">
$(document).ready(function() {

    
    var readURL = function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('.avatar').attr('src', e.target.result);
            }
    
            reader.readAsDataURL(input.files[0]);
        }
    }

    	<div class="col-md-9">
		    <div class="card">
		        <div class="card-body">
		            <div class="row">
		                <div class="col-md-12">
		                    <h4>Your Profile</h4>
		                    <hr>
		                </div>
		            </div>
		            <div class="row">
		                <div class="col-md-12">
		                    <form>
                              <div class="form-group row">
                                <label for="username" class="col-4 col-form-label">User Name*</label> 
                                <div class="col-8">
                                  <input id="username" name="username" placeholder="Username" class="form-control here" required="required" type="text">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="name" class="col-4 col-form-label">First Name</label> 
                                <div class="col-8">
                                  <input id="name" name="name" placeholder="First Name" class="form-control here" type="text">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="lastname" class="col-4 col-form-label">Last Name</label> 
                                <div class="col-8">
                                  <input id="lastname" name="lastname" placeholder="Last Name" class="form-control here" type="text">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="text" class="col-4 col-form-label">Nick Name*</label> 
                                <div class="col-8">
                                  <input id="text" name="text" placeholder="Nick Name" class="form-control here" required="required" type="text">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="select" class="col-4 col-form-label">Display Name public as</label> 
                                <div class="col-8">
                                  <select id="select" name="select" class="custom-select">
                                    <option value="admin">Admin</option>
                                  </select>
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="email" class="col-4 col-form-label">Email*</label> 
                                <div class="col-8">
                                  <input id="email" name="email" placeholder="Email" class="form-control here" required="required" type="text">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="website" class="col-4 col-form-label">Website</label> 
                                <div class="col-8">
                                  <input id="website" name="website" placeholder="website" class="form-control here" type="text">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="publicinfo" class="col-4 col-form-label">Public Info</label> 
                                <div class="col-8">
                                  <textarea id="publicinfo" name="publicinfo" cols="40" rows="4" class="form-control"></textarea>
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="newpass" class="col-4 col-form-label">New Password</label> 
                                <div class="col-8">
                                  <input id="newpass" name="newpass" placeholder="New Password" class="form-control here" type="text">
                                </div>
                              </div> 
                              <div class="form-group row">
                                <div class="offset-4 col-8">
                                  <button name="submit" type="submit" class="btn btn-primary">Update My Profile</button>
                                </div>
                              </div>
                            </form>
		                </div>
		            </div>
		            
		        </div>
		    </div>
    

    $(".file-upload").on('change', function(){
        readURL(this);
    });
});
</script>
</body>
</html>
